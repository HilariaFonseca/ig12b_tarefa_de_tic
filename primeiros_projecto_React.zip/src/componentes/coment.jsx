import React from 'react';
import "./coment"

function Coment (){
    return(
        <>
        <section className='comment'>
            <p className='titulo'> Titulo</p>
            <p className='texto'>
            Texto do comrntario
         </p>
            <p className='autor'>Autor: Hilária Chiquito </p>

        </section>
        </>
    )
} 

export default Coment