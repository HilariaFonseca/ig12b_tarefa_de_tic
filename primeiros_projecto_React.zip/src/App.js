import React from 'react';
 
//import TEXTO from './componentes/texto'
import Coment from './componentes/coment'


function App() {
  return (
    <>  
    <h1>Comentario</h1>
        <Coment/>
        <Coment/>
        <Coment/>
         
    </>
    
  );
}

export default App;
