 import React from 'react';

 function TEXTO(){
    return(
        <>

        <h1>Olá React!</h1>
          <h3>  TEXTO:  oi Hilaria</h3>
        </>
    )
 }

 export default TEXTO;