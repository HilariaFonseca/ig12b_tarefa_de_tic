import React from 'react';
import "./coment"

function Coment (props){
    function Maisculas(texto){
        return texto.toUpperCase()
    }
    return(
        <>
        <section className='comment'>
            <p className='titulo'> {Maisculas(props.titulo)}</p>
            <p className='texto'>
            Texto do comrntario
         </p>
            <p className='autor'>{props.autor}</p>

        </section>
        </>
    )
} 

export default Coment